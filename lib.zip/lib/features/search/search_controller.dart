import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iptv/app/providers.dart';
import 'package:iptv/core/utils/result.dart';
import 'package:iptv/domain/entities/channel.dart';
import 'package:iptv/domain/entities/movie.dart';
import 'package:iptv/domain/entities/series.dart';
import 'package:iptv/domain/repositories/live_repository.dart';
import 'package:iptv/domain/repositories/series_repository.dart';
import 'package:iptv/domain/repositories/vod_repository.dart';

class SearchState {
  const SearchState({
    this.query = '',
    this.channels = const [],
    this.movies = const [],
    this.series = const [],
    this.isLoading = false,
  });

  final String query;
  final List<Channel> channels;
  final List<Movie> movies;
  final List<Series> series;
  final bool isLoading;

  bool get isEmpty =>
      query.isEmpty || (channels.isEmpty && movies.isEmpty && series.isEmpty);

  int get totalResults => channels.length + movies.length + series.length;
}

class SearchController extends StateNotifier<SearchState> {
  SearchController(this._liveRepo, this._vodRepo, this._seriesRepo)
      : super(const SearchState());

  final LiveRepository? _liveRepo;
  final VodRepository? _vodRepo;
  final SeriesRepository? _seriesRepo;

  int _searchToken = 0;

  Future<void> search(String query) async {
    final currentToken = ++_searchToken;
    final trimmed = query.trim();

    if (trimmed.isEmpty) {
      state = const SearchState();
      return;
    }

    state = SearchState(query: trimmed, isLoading: true);

    try {
      final q = trimmed.toLowerCase();

      final channelsFuture = _liveRepo?.getChannels() ??
          Future.value(const Err(AppResultError('No repo')));
      final moviesFuture = _vodRepo?.getMovies() ??
          Future.value(const Err(AppResultError('No repo')));
      final seriesFuture = _seriesRepo?.getSeries() ??
          Future.value(const Err(AppResultError('No repo')));

      final results = await Future.wait([
        channelsFuture,
        moviesFuture,
        seriesFuture,
      ]);

      // If a newer search or clear request was issued, discard this response
      if (_searchToken != currentToken) {
        return;
      }

      final channels = results[0].when(
        ok: (list) => (list as List<Channel>)
            .where((c) => c.name.toLowerCase().contains(q))
            .take(30)
            .toList(),
        err: (_) => <Channel>[],
      );

      final movies = results[1].when(
        ok: (list) => (list as List<Movie>)
            .where((m) => m.name.toLowerCase().contains(q))
            .take(30)
            .toList(),
        err: (_) => <Movie>[],
      );

      final series = results[2].when(
        ok: (list) => (list as List<Series>)
            .where((s) => s.name.toLowerCase().contains(q))
            .take(30)
            .toList(),
        err: (_) => <Series>[],
      );

      state = SearchState(
        query: trimmed,
        channels: channels,
        movies: movies,
        series: series,
        isLoading: false,
      );
    } catch (_) {
      if (_searchToken == currentToken) {
        state = SearchState(query: trimmed, isLoading: false);
      }
    }
  }

  void clear() {
    _searchToken++;
    state = const SearchState();
  }
}

final searchControllerProvider =
    StateNotifierProvider<SearchController, SearchState>((ref) {
  final liveRepo = ref.watch(liveRepositoryProvider);
  final vodRepo = ref.watch(vodRepositoryProvider);
  final seriesRepo = ref.watch(seriesRepositoryProvider);
  return SearchController(liveRepo, vodRepo, seriesRepo);
});
