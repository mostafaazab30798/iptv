import 'package:iptv/core/utils/result.dart';
import 'package:iptv/data/datasources/xtream_remote_datasource.dart';
import 'package:iptv/data/mappers/data_mapper.dart';
import 'package:iptv/domain/entities/category.dart';
import 'package:iptv/domain/entities/channel.dart';
import 'package:iptv/domain/repositories/live_repository.dart';

class LiveRepositoryImpl implements LiveRepository {
  const LiveRepositoryImpl({required this.remoteDataSource});

  final XtreamRemoteDataSource remoteDataSource;

  @override
  Future<Result<List<Category>>> getCategories({bool forceRefresh = false}) async {
    try {
      final raw = await remoteDataSource.getLiveCategories();
      final categories = raw.map((j) => DataMapper.categoryFromJson(j, CategoryType.live)).toList();
      return Ok(categories);
    } catch (e) {
      return Err(AppResultError('Failed to load live categories', cause: e));
    }
  }

  @override
  Future<Result<List<Channel>>> getChannels({
    int? categoryId,
    bool forceRefresh = false,
  }) async {
    try {
      final raw = await remoteDataSource.getLiveStreams(categoryId: categoryId);
      final channels = raw.map(DataMapper.channelFromJson).toList();
      return Ok(channels);
    } catch (e) {
      return Err(AppResultError('Failed to load channels', cause: e));
    }
  }

  @override
  Future<Result<Channel>> getChannelById(int streamId) async {
    try {
      final raw = await remoteDataSource.getLiveStreams();
      final item = raw.firstWhere(
        (j) => int.tryParse(j['stream_id']?.toString() ?? '') == streamId,
        orElse: () => throw Exception('Channel not found'),
      );
      return Ok(DataMapper.channelFromJson(item));
    } catch (e) {
      return Err(AppResultError('Channel not found', cause: e));
    }
  }
}
